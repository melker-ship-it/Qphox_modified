from CryoSwitchController import Cryoswitch

ok = Cryoswitch()
ok.start()
ok.set_output_voltage(5)
ok.set_pulse_duration_ms(100)
#port={'A'} 
#contact={1}
#ok.connect(port, contact)